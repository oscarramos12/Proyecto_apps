package com.example.proyecto.ui.sign

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.proyecto.database.ProyectoDao
import com.example.proyecto.database.User
import kotlinx.coroutines.*

class SignViewModel (val database: ProyectoDao): ViewModel() {
    val user = MutableLiveData<String>()
    val password= MutableLiveData<String>()


    private val viewModelJob= Job()


    private val uiScope= CoroutineScope(Dispatchers.Main+viewModelJob)

    fun insertUser(){
        uiScope.launch {
            insert()
        }


    }



    private suspend fun insert(){
        withContext(Dispatchers.IO) {

            database.clear()
            database.insert(User(username = user.value?:"",password = password.value?:""))




        }




    }

    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }


}