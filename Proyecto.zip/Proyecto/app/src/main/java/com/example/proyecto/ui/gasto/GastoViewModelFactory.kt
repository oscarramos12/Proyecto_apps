package com.example.proyecto.ui.gasto

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.proyecto.database.ProyectoDao
import com.example.proyecto.ui.ingreso.IngresoViewModel
import java.lang.IllegalArgumentException

class GastoViewModelFactory (private val database: ProyectoDao): ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(GastoViewModel::class.java))
            return GastoViewModel(database) as T
        throw IllegalArgumentException("Unknown ViewModel Class")

    }



}