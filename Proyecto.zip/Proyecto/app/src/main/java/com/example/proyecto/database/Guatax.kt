package com.example.proyecto.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="guatax_table")
data class Guatax (
    @PrimaryKey(autoGenerate = true)
    var cuentaId:Long=0L,

    @ColumnInfo(name="cuenta")
    var cuenta:String="",

    @ColumnInfo(name="monto")
    var monto:String=""








)