package com.example.proyecto.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.proyecto.database.*
import kotlinx.coroutines.*
import java.lang.StringBuilder

class HomeViewModel (val database: ProyectoDao): ViewModel(){
    var allCuentas= database.getAllCuenta()
    var montoFinal=MutableLiveData<String>()
    var allCalculos=database.getCalculos()
    val cuents= Transformations.map(allCuentas){

        encontrarCuenta(it)
    }

    val calcs=Transformations.map(allCalculos){


        getCal(it)
    }
    private val viewModelJob= Job()






    private fun encontrarCuenta(cuenta:List<Guatax>):String{

        var cuentas= StringBuilder()

        for(cuen in cuenta)
            cuentas.append(" No. ${cuen.cuentaId}"+" Cuenta: ${cuen.cuenta}"+" Monto: Q${cuen.monto}\n")


        return cuentas.toString()



    }
    private fun getCal(calculos: List<Calculos>):String{

        var calcs=StringBuilder()

        for(c in calculos)
            if("${c.calculo_ingreso}"=="")
                calcs.append("\nGasto: Q${c.calculo_gasto}\n")
            else if ("${c.calculo_gasto}"=="")
                calcs.append("\nIngreso: Q${c.calculo_ingreso}\n")
        else
                calcs.append("\nIngreso: Q${c.calculo_ingreso}\nGasto: Q${c.calculo_gasto}\n")


        return calcs.toString()

    }






    private val uiScope= CoroutineScope(Dispatchers.Main+viewModelJob)

    fun insertMonto(){
        uiScope.launch {
            insert()
        }


    }



    private suspend fun insert(){
        withContext(Dispatchers.IO) {

            database.clearMonto()
            database.insertCalculo(Calculos(calculo_monto =montoFinal.value?:""))


        }




    }

    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }






}