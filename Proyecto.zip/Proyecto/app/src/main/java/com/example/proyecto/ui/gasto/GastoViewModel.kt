package com.example.proyecto.ui.gasto

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.proyecto.database.Calculos
import com.example.proyecto.database.ProyectoDao
import kotlinx.coroutines.*

class GastoViewModel(val database: ProyectoDao): ViewModel() {
    var gasto= MutableLiveData<String>()
    var monto= MutableLiveData<String>()

    private val viewModelJob= Job()


    private val uiScope= CoroutineScope(Dispatchers.Main+viewModelJob)

    fun insertGasto(){
        uiScope.launch {
            insert()
        }


    }



    private suspend fun insert(){
        withContext(Dispatchers.IO) {

            /*val m=monto.value.toString().toFloat()
            val i=ingreso.value.toString().toFloat()
            val t= m+i*/
            database.insertCalculo(Calculos(calculo_gasto = gasto.value?:""))




        }




    }


    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }


}
