package com.example.proyecto.ui.ingreso

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.proyecto.database.Calculos
import com.example.proyecto.database.Guatax
import com.example.proyecto.database.ProyectoDao
import kotlinx.coroutines.*

class IngresoViewModel (val database: ProyectoDao): ViewModel() {


    var ingreso=MutableLiveData<String>()
    var monto=MutableLiveData<String>()

    private val viewModelJob= Job()


    private val uiScope= CoroutineScope(Dispatchers.Main+viewModelJob)

    fun insertIngreso(){
        uiScope.launch {
            insert()
        }


    }



    private suspend fun insert(){
        withContext(Dispatchers.IO) {

            /*val m=monto.value.toString().toFloat()
            val i=ingreso.value.toString().toFloat()
            val t= m+i*/
            database.clearCalculos()
            database.insertCalculo(Calculos(calculo_ingreso = ingreso.value?:""))




        }




    }


    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }

}
