package com.example.proyecto.ui.insights

import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.proyecto.database.Calculos
import com.example.proyecto.database.montoEspecial
import com.example.proyecto.database.ProyectoDao
import kotlinx.coroutines.Job
import java.lang.StringBuilder

class InsightsViewModel (val database: ProyectoDao): ViewModel() {
    var allCalculos=database.getCalculos()

    var allMonto=database.getAllMonto()
    val gastosT= Transformations.map(allCalculos){

        getGastos(it)
    }

    val ingresosT= Transformations.map(allCalculos){


        getIngresos(it)
    }
    val m=Transformations.map(allCalculos){

        getNeto(it)
    }






    private val viewModelJob= Job()


    private fun getGastos(calculos: List<Calculos>):String{

        val gastos=StringBuilder()

        for(c in calculos)
            gastos.append("${c.calculo_gasto}.")

        val lista: MutableList<String>
        lista=gastos.toString().split(".").toMutableList()
        while(lista.contains(""))
            lista.remove("")


        val tt:Double=lista.sumByDouble { it.toDouble() }

        val f="Gastos Totales: "+tt.toString()
        return f

    }

    private fun getIngresos(calculos: List<Calculos>):String{

        val gastos=StringBuilder()

        for(c in calculos)
            gastos.append("${c.calculo_ingreso}.")

        val lista: MutableList<String>
        lista=gastos.toString().split(".").toMutableList()
        while(lista.contains(""))
            lista.remove("")


        val tt:Double=lista.sumByDouble { it.toDouble() }

        val f="Ingresos Totales: "+tt.toString()
        return f

    }
    private fun getNeto(calculos: List<Calculos>):String{

        val gastos=StringBuilder()
        val ingresos=StringBuilder()
        val monto=StringBuilder()

        for(c in calculos)
            gastos.append("${c.calculo_gasto}.")
        for(c in calculos)
            ingresos.append("${c.calculo_ingreso}")
        for(c in calculos)
            ingresos.append("${c.calculo_monto}")



        val lista2: MutableList<String>
        lista2=ingresos.toString().split(".").toMutableList()
        while(lista2.contains(""))
            lista2.remove("")


        val tt2:Double=lista2.sumByDouble { it.toDouble() }

        val lista3: MutableList<String>
        lista3=gastos.toString().split(".").toMutableList()
        while(lista3.contains(""))
            lista3.remove("")


        val tt3:Double=lista3.sumByDouble { it.toDouble() }


        val lista: MutableList<String>
        lista=gastos.toString().split(".").toMutableList()
        while(lista.contains(""))
            lista.remove("")


        val tt:Double=lista.sumByDouble { it.toDouble() }
        val f= tt2-tt

        val final= (tt3+f)*0.21
        val r=""
        if(final<0)
            return "Perdida neta: "+final.toString()
        else
            return "Ganancia neta: "+final.toString()



    }






    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }

}
