package com.example.proyecto.ui.cuenta

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.proyecto.database.Guatax
import com.example.proyecto.database.ProyectoDao
import com.example.proyecto.database.User
import kotlinx.coroutines.*
import java.lang.StringBuilder

class CuentaViewModel (val database: ProyectoDao): ViewModel(){


    var cuenta=MutableLiveData<String>()

    var monto= MutableLiveData<String>()


    private val viewModelJob= Job()


    private val uiScope= CoroutineScope(Dispatchers.Main+viewModelJob)

    fun insertCuenta(){
        uiScope.launch {
            insert()
        }


    }



    private suspend fun insert(){
        withContext(Dispatchers.IO) {
            database.insertCuenta(Guatax(cuenta=cuenta.value?:"",monto =monto.value?:"" ))




        }




    }


    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }



}