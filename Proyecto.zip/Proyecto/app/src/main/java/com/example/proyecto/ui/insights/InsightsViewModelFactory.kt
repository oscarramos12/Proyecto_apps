package com.example.proyecto.ui.insights

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.proyecto.database.ProyectoDao
import com.example.proyecto.ui.home.HomeViewModel
import java.lang.IllegalArgumentException

class InsightsViewModelFactory (private val database: ProyectoDao): ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(InsightsViewModel::class.java))
            return InsightsViewModel(database) as T
        throw IllegalArgumentException("Unknown ViewModel Class")

    }



}