package com.example.proyecto.ui.factura

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.proyecto.R
import com.example.proyecto.databinding.FragmentCuentaBinding
import com.example.proyecto.databinding.FragmentFacturaBinding

class FacturaFragment : Fragment() {

    private lateinit var facturaViewModel: FacturaViewModel
    private lateinit var binding: FragmentFacturaBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_factura, container, false)


        return binding.root
    }
}