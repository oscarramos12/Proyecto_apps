package com.example.proyecto.ui.insights

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.example.proyecto.R
import com.example.proyecto.database.ProyectoDataBase
import com.example.proyecto.databinding.FragmentHomeBinding
import com.example.proyecto.databinding.FragmentInsightsBinding
import com.example.proyecto.ui.ingreso.IngresoViewModel
import com.example.proyecto.ui.ingreso.IngresoViewModelFactory


class InsightsFragment : Fragment() {

    private lateinit var binding: FragmentInsightsBinding
    private lateinit var insightsViewModel:InsightsViewModel
    private lateinit var insightsViewModelFactory: InsightsViewModelFactory


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_insights, container, false)
        

        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.lifecycleOwner=this
        val application= requireNotNull(this.activity).application
        val dataSource= ProyectoDataBase.getInstance(application).proyectoDao
        insightsViewModelFactory= InsightsViewModelFactory(dataSource)
        insightsViewModel= ViewModelProvider(this, insightsViewModelFactory).get(InsightsViewModel::class.java)
        binding.insightsViewModel= insightsViewModel

        //val t= binding.textView7.text.toString()



    }


}
