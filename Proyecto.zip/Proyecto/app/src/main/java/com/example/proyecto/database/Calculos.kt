package com.example.proyecto.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "calculos_tabla")
data class Calculos(

    @PrimaryKey(autoGenerate = true)
    var calculosId:Long=0L,

    @ColumnInfo(name="calculo_ingreso")
    var calculo_ingreso:String="",

    @ColumnInfo(name="calculo_gasto")
    var calculo_gasto:String="",

    @ColumnInfo(name="calculo_monto")
    var calculo_monto:String=""


)
