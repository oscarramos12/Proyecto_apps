package com.example.proyecto.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.findNavController
import com.example.proyecto.R
import com.example.proyecto.database.ProyectoDataBase
import com.example.proyecto.databinding.FragmentHomeBinding
import java.lang.StringBuilder

class HomeFragment : Fragment() {

    companion object {
        fun newInstance() = HomeFragment()
    }

    private lateinit var binding:FragmentHomeBinding
    private lateinit var homeViewModel:HomeViewModel
    private lateinit var homeViewModelFactory: HomeViewModelFactory


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false)
        (activity as AppCompatActivity).supportActionBar?.show()

        return binding.root
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.lifecycleOwner=this
        val application= requireNotNull(this.activity).application
        val dataSource= ProyectoDataBase.getInstance(application).proyectoDao
        homeViewModelFactory= HomeViewModelFactory(dataSource)
        homeViewModel= ViewModelProvider(this, homeViewModelFactory).get(HomeViewModel::class.java)
        binding.homeViewModel= homeViewModel




        binding.button.setOnClickListener {

            val cuentas= binding.cuentasText.text.toString()
            val cuentaDeseada= StringBuilder()

            val lista: List<String>

            lista= cuentas.split("\n")


            for(l in lista){

                if(l.contains(binding.nombreCuenta.text.toString())){
                    cuentaDeseada.append(l)

                }

            }
            val monto:List<String>
            monto=cuentaDeseada.toString().split("Monto: Q")
            val monto2=monto[1]
            binding.montoDeseado.text=monto2
            homeViewModel.insertMonto()


        }




        binding.addCuentaBtn.setOnClickListener {


            it.findNavController().navigate(R.id.action_nav_home_to_nav_cuenta)
        }


        binding.facturaBtn.setOnClickListener {

            it.findNavController().navigate(R.id.action_nav_home_to_nav_factura)
        }

        binding.ingresoBtn.setOnClickListener {

            it.findNavController().navigate(R.id.action_nav_home_to_nav_ingreso)



            homeViewModel.insertMonto()
        }

        binding.gastoBtn.setOnClickListener {
            it.findNavController().navigate(R.id.action_nav_home_to_nav_gasto)
        }


    }
}