package com.example.proyecto.ui.gasto

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.example.proyecto.R
import com.example.proyecto.database.ProyectoDataBase
import com.example.proyecto.databinding.FragmentGastoBinding
import com.example.proyecto.ui.ingreso.IngresoViewModel
import com.example.proyecto.ui.ingreso.IngresoViewModelFactory


class GastoFragment : Fragment() {

  private lateinit var binding: FragmentGastoBinding
    private lateinit var gastoViewModel: GastoViewModel
    private lateinit var gastoViewModelFactory: GastoViewModelFactory

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_gasto, container, false)


        return binding.root


    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        binding.lifecycleOwner=this
        val application= requireNotNull(this.activity).application
        val dataSource= ProyectoDataBase.getInstance(application).proyectoDao
        gastoViewModelFactory= GastoViewModelFactory(dataSource)
        gastoViewModel= ViewModelProvider(this, gastoViewModelFactory).get(GastoViewModel::class.java)
        binding.gastoViewModel= gastoViewModel

        binding.ingresoBtn2.setOnClickListener {

            gastoViewModel.insertGasto()
            it.findNavController().navigate(R.id.action_nav_gasto_to_nav_home)
        }



    }
}
