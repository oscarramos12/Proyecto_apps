package com.example.proyecto.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ProyectoDao{
    @Insert
    fun insert(user:User)
    @Query("DELETE FROM user_table" )
    fun clear()

    @Query ("SELECT *FROM user_table ORDER BY userId DESC")
    fun getAllUser():LiveData<List<User>>

//////////// Guatax////////////////


    @Insert
    fun insertCuenta(guatax: Guatax)

    @Query("SELECT * FROM guatax_table")
    fun getAllCuentas():LiveData<List<Guatax>>

    @Query("SELECT *FROM guatax_table ORDER BY cuentaId ASC")
    fun getCuenta():LiveData<List<Guatax>>

    @Query("SELECT * FROM guatax_table")
    fun getAllCuenta(): LiveData<List<Guatax>>


    @Insert
    fun insertMonto(montoEspecial: montoEspecial)

    @Query("DELETE FROM monto_table")
    fun clearMonto()

    @Query("SELECT * FROM monto_table")
    fun getAllMonto():LiveData<List<montoEspecial>>


    @Insert
    fun insertCalculo(calculos: Calculos)

    @Query("DELETE FROM calculos_tabla")
    fun clearCalculos()

    @Query("SELECT * FROM calculos_tabla")
    fun getCalculos():LiveData<List<Calculos>>









}

