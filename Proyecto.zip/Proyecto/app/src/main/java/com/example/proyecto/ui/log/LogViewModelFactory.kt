package com.example.proyecto.ui.log

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.proyecto.database.ProyectoDao
import com.example.proyecto.ui.sign.SignViewModel
import java.lang.IllegalArgumentException

class LogViewModelFactory (private val database: ProyectoDao): ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(LogViewModel::class.java))
            return LogViewModel(database) as T
        throw IllegalArgumentException("Unknown ViewModel Class")

    }



}