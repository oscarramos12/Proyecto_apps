package com.example.proyecto.ui.log

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.proyecto.database.ProyectoDao
import com.example.proyecto.database.User
import kotlinx.coroutines.Job
import java.lang.StringBuilder

class LogViewModel (val database: ProyectoDao): ViewModel() {

    private var viewModelJob= Job()
    private var allUsers=database.getAllUser()
    private var allPass=database.getAllUser()
    val users= Transformations.map(allUsers){

        getUsers(it)
    }

    val pas=Transformations.map(allPass){
        getPass(it)
    }


    private fun getUsers(users:List<User>):String{
        val allUs=StringBuilder()
        for(use in users)
            allUs.append("${use.username}")

        return allUs.toString()


    }
    private fun getPass(users:List<User>):String{
        val allUs=StringBuilder()
        for(use in users)
            allUs.append("${use.password}")

        return allUs.toString()


    }

}