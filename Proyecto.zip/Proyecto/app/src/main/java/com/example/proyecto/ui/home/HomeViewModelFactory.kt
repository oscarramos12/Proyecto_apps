package com.example.proyecto.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.proyecto.database.ProyectoDao

import java.lang.IllegalArgumentException

public class  HomeViewModelFactory(private val database: ProyectoDao): ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(HomeViewModel::class.java))
            return HomeViewModel(database) as T
        throw IllegalArgumentException("Unknown ViewModel Class")

    }



}