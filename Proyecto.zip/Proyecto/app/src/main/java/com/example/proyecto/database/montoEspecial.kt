package com.example.proyecto.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "monto_table")
data class montoEspecial(

    @PrimaryKey(autoGenerate = true)
    val montoId:Long=0L,

    @ColumnInfo(name="monto")
    val monto:String=""

)
