package com.example.proyecto.ui.sign

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.proyecto.database.ProyectoDao
import java.lang.IllegalArgumentException

class SignViewModelFactory(private val database: ProyectoDao): ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(SignViewModel::class.java))
            return SignViewModel(database) as T
        throw IllegalArgumentException("Unknown ViewModel Class")

    }



}
