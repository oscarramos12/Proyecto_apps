package com.example.proyecto.ui.log

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.example.proyecto.R
import com.example.proyecto.database.ProyectoDataBase
import com.example.proyecto.databinding.FragmentLogBinding

class LogFragment : Fragment() {

    companion object {
        fun newInstance() = LogFragment()
    }

    private lateinit var binding: FragmentLogBinding
    private lateinit var logViewModel: LogViewModel
    private lateinit var logViewModelFactory: LogViewModelFactory


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_log, container, false)

        return binding.root
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.lifecycleOwner=this

        val application= requireNotNull(this.activity).application
        val dataSource= ProyectoDataBase.getInstance(application).proyectoDao
        logViewModelFactory= LogViewModelFactory(dataSource)
        logViewModel= ViewModelProvider(this, logViewModelFactory).get(LogViewModel::class.java)
        binding.logViewModel=logViewModel
        binding.logBtn.setOnClickListener {
            val user= binding.textView.text.toString()
            val pass = binding.textView2.text.toString()

            if(binding.logUsernameText.text.toString()==user && binding.logPasswordText.text.toString()==pass ){

                it.findNavController().navigate(R.id.action_nav_log_to_nav_home)
            }

        }

        binding.backBtn.setOnClickListener {
            it.findNavController().navigate(R.id.action_nav_log_to_nav_start)
        }

    }
}