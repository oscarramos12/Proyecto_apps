package com.example.proyecto.ui.ingreso

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.proyecto.database.ProyectoDao
import com.example.proyecto.ui.home.HomeViewModel
import java.lang.IllegalArgumentException

class IngresoViewModelFactory(private val database: ProyectoDao): ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(IngresoViewModel::class.java))
            return IngresoViewModel(database) as T
        throw IllegalArgumentException("Unknown ViewModel Class")

    }



}