package com.example.proyecto.ui.ingreso

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.example.proyecto.R
import com.example.proyecto.database.ProyectoDataBase
import com.example.proyecto.databinding.FragmentGastoBinding
import com.example.proyecto.databinding.FragmentIngresoBinding


class IngresoFragment : Fragment() {

    private lateinit var binding: FragmentIngresoBinding
    private lateinit var ingresoViewModel: IngresoViewModel
    private lateinit var ingresoViewModelFactory: IngresoViewModelFactory

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_ingreso, container, false)
        //(activity as AppCompatActivity).supportActionBar?.show()

        return binding.root


    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        binding.lifecycleOwner=this
        val application= requireNotNull(this.activity).application
        val dataSource= ProyectoDataBase.getInstance(application).proyectoDao
        ingresoViewModelFactory= IngresoViewModelFactory(dataSource)
        ingresoViewModel= ViewModelProvider(this, ingresoViewModelFactory).get(IngresoViewModel::class.java)
        binding.ingresoViewModel= ingresoViewModel

        binding.ingresoBtn.setOnClickListener {

            ingresoViewModel.insertIngreso()
            it.findNavController().navigate(R.id.action_nav_ingreso_to_nav_home)
        }



    }
}
