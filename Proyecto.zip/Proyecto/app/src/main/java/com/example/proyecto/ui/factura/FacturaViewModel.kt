package com.example.proyecto.ui.factura

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.proyecto.database.ProyectoDao

class FacturaViewModel (val database: ProyectoDao): ViewModel() {


}