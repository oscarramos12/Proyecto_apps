package com.example.proyecto.ui.factura

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.proyecto.database.ProyectoDao
import com.example.proyecto.ui.home.HomeViewModel
import java.lang.IllegalArgumentException

class FacturaViewModelFactory (private val database: ProyectoDao): ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(FacturaViewModel::class.java))
            return FacturaViewModel(database) as T
        throw IllegalArgumentException("Unknown ViewModel Class")

    }



}